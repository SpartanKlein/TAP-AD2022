public class Equipo {
    private int idClave;
    private String tipoComputadora;
    private String marca;
    private String modelo;
    private String procesador;
    private String memoria;
    private String almacenamiento;

    public Equipo() {
    }

    public Equipo(int var1, String var2, String var3, String var4, String var5, String var6, String var7) {
        this.establecerIDClave(var1);
        this.establecerTipoComputadora(var2);
        this.establecerMarca(var3);
        this.establecerModelo(var4);
        this.establecerProcesador(var5);
        this.establecerMemoria(var6);
        this.establecerAlmacenamiento(var7);
    }

    public void establecerIDClave(int var1) {
        this.idClave = var1;
    }

    public int obtenerIDClave() {
        return this.idClave;
    }

    public void establecerTipoComputadora(String var1) {
        this.tipoComputadora = var1;
    }

    public String obtenerTipoComputadora() {
        return this.tipoComputadora;
    }

    public void establecerMarca(String var1) {
        this.marca = var1;
    }

    public String obtenerMarca() {
        return this.marca;
    }

    public void establecerModelo(String var1) {
        this.modelo = var1;
    }

    public String obtenerModelo() {
        return this.modelo;
    }

    public void establecerProcesador(String var1) {
        this.procesador = var1;
    }

    public String obtenerProcesador() {
        return this.procesador;
    }

    public void establecerMemoria(String var1) {
        this.memoria = var1;
    }

    public String obtenerMemoria() {
        return this.memoria;
    }

    public void establecerAlmacenamiento(String var1) {
        this.almacenamiento = var1;
    }

    public String obtenerAlmacenamiento() {
        return this.almacenamiento;
    }
}
