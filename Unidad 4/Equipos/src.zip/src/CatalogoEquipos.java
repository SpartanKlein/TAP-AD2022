public class CatalogoEquipos {
    public CatalogoEquipos() {
    }

    public static void main(String[] var0) {
        MiVentanaCatalogo var1 = new MiVentanaCatalogo("Catálogo de Equipos");
        var1.setDefaultCloseOperation(0);
        var1.setSize(600, 300);
        var1.setVisible(true);
    }
}
