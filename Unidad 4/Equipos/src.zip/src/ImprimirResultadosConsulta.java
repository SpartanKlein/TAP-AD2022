import java.awt.Component;
import java.awt.print.PrinterException;
import java.sql.SQLException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class ImprimirResultadosConsulta extends JFrame{
        static final String CONTROLADOR = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
        static final String URL_BASEDATOS = "jdbc:sqlserver://localhost;databaseName=Evaluacion;";
        static final String NOMBREUSUARIO = "jhtp7";
        static final String CONTRASENIA = "jhtp7";
        static final String CONSULTA_PREDETERMINADA = "SELECT * FROM Equipos";
        private ResultSetTableModel modeloTabla;

        public ImprimirResultadosConsulta() {
                try {
                        this.modeloTabla = new ResultSetTableModel("com.microsoft.sqlserver.jdbc.SQLServerDriver", "jdbc:sqlserver://localhost;databaseName=Evaluacion;", "jhtp7", "jhtp7", "SELECT * FROM Equipos");
                        JTable var1 = new JTable(this.modeloTabla);
                        this.add(new JScrollPane(var1));
                        this.setSize(500, 250);
                        this.setVisible(false);

                        try {
                                var1.print();
                        } catch (PrinterException var3) {
                                JOptionPane.showMessageDialog((Component)null, var3.getMessage(), "Error al imprimir", 0);
                        }
                } catch (ClassNotFoundException var4) {
                        JOptionPane.showMessageDialog((Component)null, "No se encontro controlador de base de datos", "No se encontro el controlador", 0);
                        System.exit(1);
                } catch (SQLException var5) {
                        JOptionPane.showMessageDialog((Component)null, var5.getMessage(), "Error en base de datos", 0);
                        this.modeloTabla.desconectarDeBaseDatos();
                        System.exit(1);
                }

        }
}
